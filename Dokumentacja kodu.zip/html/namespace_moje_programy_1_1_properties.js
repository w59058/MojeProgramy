var namespace_moje_programy_1_1_properties =
[
    [ "Resources", "class_moje_programy_1_1_properties_1_1_resources.html", null ],
    [ "Settings", "class_moje_programy_1_1_properties_1_1_settings.html", null ]
];