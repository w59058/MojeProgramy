var hierarchy =
[
    [ "Application", null, [
      [ "MojeProgramy::App", "class_moje_programy_1_1_app.html", null ],
      [ "MojeProgramy::App", "class_moje_programy_1_1_app.html", null ]
    ] ],
    [ "ApplicationSettingsBase", null, [
      [ "MojeProgramy::Properties::Settings", "class_moje_programy_1_1_properties_1_1_settings.html", null ]
    ] ],
    [ "IComponentConnector", null, [
      [ "MojeProgramy::MainWindow", "class_moje_programy_1_1_main_window.html", null ]
    ] ],
    [ "IStyleConnector", null, [
      [ "MojeProgramy::MainWindow", "class_moje_programy_1_1_main_window.html", null ]
    ] ],
    [ "MojeProgramy.Program", "class_moje_programy_1_1_program.html", null ],
    [ "MojeProgramy::Properties::Resources", "class_moje_programy_1_1_properties_1_1_resources.html", null ],
    [ "Window", null, [
      [ "MojeProgramy::MainWindow", "class_moje_programy_1_1_main_window.html", null ],
      [ "MojeProgramy::MainWindow", "class_moje_programy_1_1_main_window.html", null ]
    ] ]
];