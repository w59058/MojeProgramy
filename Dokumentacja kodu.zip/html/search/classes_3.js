var searchData=
[
  ['resources_25',['Resources',['../class_moje_programy_1_1_properties_1_1_resources.html',1,'MojeProgramy::Properties']]]
];
