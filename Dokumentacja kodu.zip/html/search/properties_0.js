var searchData=
[
  ['install_40',['Install',['../class_moje_programy_1_1_program.html#a63304168a854ee0a9212167892397dba',1,'MojeProgramy::Program']]]
];
