var searchData=
[
  ['link_5',['Link',['../class_moje_programy_1_1_program.html#a8a61aa66a583f9ab7fc8af720522148b',1,'MojeProgramy::Program']]]
];
