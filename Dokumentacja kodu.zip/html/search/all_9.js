var searchData=
[
  ['version_21',['Version',['../class_moje_programy_1_1_program.html#a48de2fb2009684943e0ea75d0e468846',1,'MojeProgramy::Program']]]
];
