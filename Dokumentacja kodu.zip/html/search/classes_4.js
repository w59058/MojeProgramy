var searchData=
[
  ['settings_26',['Settings',['../class_moje_programy_1_1_properties_1_1_settings.html',1,'MojeProgramy::Properties']]]
];
