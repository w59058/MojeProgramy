var searchData=
[
  ['resources_14',['Resources',['../class_moje_programy_1_1_properties_1_1_resources.html',1,'MojeProgramy::Properties']]],
  ['resources_2edesigner_2ecs_15',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]]
];
