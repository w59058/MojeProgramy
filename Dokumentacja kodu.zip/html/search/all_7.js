var searchData=
[
  ['settings_16',['Settings',['../class_moje_programy_1_1_properties_1_1_settings.html',1,'MojeProgramy::Properties']]],
  ['settings_2edesigner_2ecs_17',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]]
];
