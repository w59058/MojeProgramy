var searchData=
[
  ['app_2eg_2ei_2ecs_29',['App.g.i.cs',['../_app_8g_8i_8cs.html',1,'']]],
  ['app_2examl_2ecs_30',['App.xaml.cs',['../_app_8xaml_8cs.html',1,'']]],
  ['assemblyinfo_2ecs_31',['AssemblyInfo.cs',['../_assembly_info_8cs.html',1,'']]]
];
