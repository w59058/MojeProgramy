var searchData=
[
  ['name_42',['Name',['../class_moje_programy_1_1_program.html#a750f3a60310d6e87dde00f9be6450779',1,'MojeProgramy::Program']]]
];
