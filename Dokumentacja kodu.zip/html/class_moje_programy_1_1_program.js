var class_moje_programy_1_1_program =
[
    [ "Install", "class_moje_programy_1_1_program.html#a63304168a854ee0a9212167892397dba", null ],
    [ "Link", "class_moje_programy_1_1_program.html#a8a61aa66a583f9ab7fc8af720522148b", null ],
    [ "Name", "class_moje_programy_1_1_program.html#a750f3a60310d6e87dde00f9be6450779", null ],
    [ "Version", "class_moje_programy_1_1_program.html#a48de2fb2009684943e0ea75d0e468846", null ]
];