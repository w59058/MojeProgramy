var namespace_moje_programy =
[
    [ "Properties", "namespace_moje_programy_1_1_properties.html", "namespace_moje_programy_1_1_properties" ],
    [ "App", "class_moje_programy_1_1_app.html", null ],
    [ "MainWindow", "class_moje_programy_1_1_main_window.html", null ],
    [ "Program", "class_moje_programy_1_1_program.html", "class_moje_programy_1_1_program" ]
];