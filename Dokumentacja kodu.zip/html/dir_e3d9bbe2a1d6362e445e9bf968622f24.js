var dir_e3d9bbe2a1d6362e445e9bf968622f24 =
[
    [ "AssemblyInfo.cs", "_assembly_info_8cs.html", null ],
    [ "Resources.Designer.cs", "_resources_8_designer_8cs.html", [
      [ "Resources", "class_moje_programy_1_1_properties_1_1_resources.html", null ]
    ] ],
    [ "Settings.Designer.cs", "_settings_8_designer_8cs.html", [
      [ "Settings", "class_moje_programy_1_1_properties_1_1_settings.html", null ]
    ] ]
];